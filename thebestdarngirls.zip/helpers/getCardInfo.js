//var inTheTheater = require('../data/inTheTheaters');

module.exports = function checkInfo(menu, option) {
	var retValue;

	return retValue;
};