var inTheTheaters = [
{
	"option":"a",
	"mtitle":"Book Club",
	"review":"Four women attend a monthly book club since 1974.  This time they will read Fifty Shades of Grey and experience a whole new world. This comedy will have you laughing at and rooting for all 4 women.  3 out of 5 stars."
},
{
	"option":"b",
	"mtitle":"Show Dogs",
	"review":"A streetwise alpha dogs will have to work with a buttoned up FBI agent undercover at a Dog Show to save a smuggled panda.  This typical cop buddy drama ups the funny ante with talking animals.  Get ready to laugh.  2.5 out of 5 stars."
},
{
	"option":"c",
	"mtitle":"Deadpool 2",
	"review":"Deadpool must save Firefist from time traveling Cable.  While Deadpool describes this as a family movie, it is for adults.  However, it is better than its predecessor.  Stay past the first set of end credits but not all the way to the end.  4.5 out of 5 stars"
},
{
	"option":"d",
	"mtitle":"Breaking In",
	"review":"After the death of her father, Shaun and her 2 kids travel to his vacation home to sell it.  But 3 men are casing the place for a treasure inside.  Be afraid of the momma lion.  This action pact movie will keep you guessing.  4 out of 5 stars"
},
{
	"option":"e",
	"mtitle":"Life of the Party",
	"review":"Deanna's husband left her for a younger woman.  Instead of feeling down, she builds herself up by enrolling in college.  Now she has to navigate divorce, studying, and socializing while beig a mom.  This comedy is nothing new.  2.5 out of 5 stars"
}
];

module.exports = inTheTheaters;

/* Rules
*  do not user '&' use the word 'and'
*/