var inTheTheaters = [
{
	"option":"a",
	"mtitle":"Solo: A Star Wars Story",
	"review":"After being seperate from his girlfriend at the Corellia border, Han will start a 3 year journey that will make him a legend.  Great in IMAX, not in 3D.  But be warned there is a lull and too much foreshadowing.  3.5 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/soloastarwarsstory.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/soloastarwarsstory.jpg"
	}
},
{
	"option":"b",
	"mtitle":"Book Club",
	"review":"Four women attend a monthly book club since 1974.  This time they will read Fifty Shades of Grey and experience a whole new world. This comedy will have you laughing at and rooting for all 4 women.  3 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/bookclub.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/bookclub.jpg"
	}
},
{
	"option":"c",
	"mtitle":"Show Dogs",
	"review":"A streetwise alpha dogs will have to work with a buttoned up FBI agent undercover at a Dog Show to save a smuggled panda.  This typical cop buddy drama ups the funny ante with talking animals.  Get ready to laugh.  2.5 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/showdogs.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/showdogs.jpg"
	}
},
{
	"option":"d",
	"mtitle":"Deadpool 2",
	"review":"Deadpool must save Firefist from time traveling Cable.  While Deadpool describes this as a family movie, it is for adults.  However, it is better than its predecessor.  Stay past the first set of end credits but not all the way to the end.  4.5 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/deadpool2.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/deadpool2.jpg"
	}
},
{
	"option":"e",
	"mtitle":"Breaking In",
	"review":"After the death of her father, Shaun and her 2 kids travel to his vacation home to sell it.  But 3 men are casing the place for a treasure inside.  Be afraid of the momma lion.  This action pact movie will keep you guessing.  4 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/breakingin.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/breakingin.jpg"
	}
}
];

module.exports = inTheTheaters;

/* Rules
*  do not user '&' use the word 'and'
*/