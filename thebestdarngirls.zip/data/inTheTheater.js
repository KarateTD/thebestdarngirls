var inTheTheaters = [
{
	"option":"a",
	"mtitle":"Mission Impossible: Fallout",
	"review":"Ethan has to fix is mistakes but with Erica's operative Walker watching his every move.  How will Ethan handle it when he is the one under suspicion.  This mission is impossible to miss and a 100% thrill ride.  See it on the big screen today.\n\n5 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/missionimpossible6.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/missionimpossible6.jpg"
	}
},
{
	"option":"b",
	"mtitle":"Mamma Mia! Here We Go Again",
	"review":"While Sophie puts her re-opening back together after a major storm, you will see how her strength parellel's her mother's when she met Sam, Harry, and Bill.  While Donna is living her moments, it just doesn't create any for the viewer.  Prequel fans, see it matinee.\n2.5 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/mammamia2.png",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/mammamia2.png"
	}
},
{
	"option":"c",
	"mtitle":"Blindspotting",
	"review":"With 3 days left on probation, Collin sees a cop shoot and kill a man.  Now he is examining is life, friendship, and love.  This movie honestly divulges that everyone has a blind spot to the pain and pressure of others.  See it now.\n\n4.5 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/blindspotting.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/blindspotting.jpg"
	}
},
{
	"option":"d",
	"mtitle":"Eighth Grade",
	"review":"Kayla has only 1 week left in the 8th grade.  After opening her time capsule from the 6th grade, she wants to put herself out there and make friends.  This movie is a real look at tweens today and how internet connection has ruined human connections.\n3 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/eightgrade.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/eightgrade.jpg"
	}
},
{
	"option":"e",
	"mtitle":"The Equalizer 2",
	"review":"Robert McCall clashes with his past when his friend Susan is killed in Belgium while investigating a case.  He won't stop until he finds the men resposible. But who will it hurt? This is a great action pack addition to the franchise.\n\n3 out of 5 stars.",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/theequalizer2.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/theequalizer2.jpg"
	}
}
];

module.exports = inTheTheaters;

/* Rules
*  do not user '&' use the word 'and'
*  small image 720w x 480h (in pixels)
*  large image 1200w x 800h (in pixels)
*/