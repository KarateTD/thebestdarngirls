var inTheTheaters = [
{
	"option":"a",
	"mtitle":"Deadpool",
	"review":"the review of Deadpool"
},
{
	"option":"b",
	"mtitle":"Breaking In",
	"review":"the review of Breaking In"
},
{
	"option":"c",
	"mtitle":"Life of the Party",
	"review":"the review of Life of the Party"
},
{
	"option":"d",
	"mtitle":"Overboard",
	"review":"the review of overboard"
},
{
	"option":"e",
	"mtitle":"Marvel's Avengers: Infinity Wars",
	"review":"the review of Marvel's Avengers: Infinity Wars"
}
];

module.exports = inTheTheaters;

/* Rules
*  do not user '&' use the word 'and'
*/