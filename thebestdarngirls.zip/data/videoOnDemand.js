var videoOnDemand = [
{
	"option":"a",
	"mtitle":"Service To Man",
	"review":"Eli and Michael are two freshman students at an all-black medical school.  However, both face harassment.  Michael for being rich and Eli for being white.  To succeed, they must work together.  This movie has a strong message with two points of view on the same topic.  5 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/servicetoman.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/servicetoman.jpg"
	}
}
];

module.exports = videoOnDemand;

/* Rules
*  do not user '&' use the word 'and'
*/