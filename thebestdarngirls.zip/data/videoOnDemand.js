var videoOnDemand = [
{
	"option":"a",
	"mtitle":"Service To Man",
	"review":"the review of Service To Man"
}
];

module.exports = videoOnDemand;

/* Rules
*  do not user '&' use the word 'and'
*/