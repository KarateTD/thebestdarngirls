var mustBuy = [
{
	"option":"a",
	"mtitle":"Black Panther",
	"review":"the review of Black Panther"
},
{
	"option":"b",
	"mtitle":"12 Strong",
	"review":"the review of 12 Strong"
},
{
	"option":"c",
	"mtitle":"Peter Rabbit",
	"review":"the review of Peter Rabbit"
},
{
	"option":"d",
	"mtitle":"Den of Thieves",
	"review":"the review of Den of Thieves"
},
{
	"option":"e",
	"mtitle":"The Post",
	"review":"the review of The Post"
}
];

module.exports = mustBuy;

/* Rules
*  do not user '&' use the word 'and'
*/