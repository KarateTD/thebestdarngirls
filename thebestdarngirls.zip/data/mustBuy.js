var mustBuy = [
{
	"option":"a",
	"mtitle":"Game Night",
	"review":"Annie and Max are a competitive couple who loves game night.  But Game Night will get very real.  This is a funny, bloody movie.  4 out of 5 stars"
},
{
	"option":"b",
	"mtitle":"Black Panther",
	"review":"After being crowned King of Wakanda, T'Chaka goes on the hunt for Klaw.  But mistakes from his father's past will put the world in jeopardy.  4.5 out of 5 stars"
},
{
	"option":"c",
	"mtitle":"12 Strong",
	"review":"After September 11th, 12 men go to Afghanistan.  However the best way to get around is on horseback.  This is a well done movie about the truth of war.  Be warned, it does get graphic.  4 out of 5 stars"
},
{
	"option":"d",
	"mtitle":"Peter Rabbit",
	"review":"Peter Rabbit must warn amimal loving Bea that her new love interst hates wildlife.  This movie is non-stop laughs for kids and adults.  4 out of 5 stars"
},
{
	"option":"e",
	"mtitle":"Den of Thieves",
	"review":"When 4 thieves decide to rob the National Federal Reserve.  It will take a strong police unit to take them down.  This movie has great comedic timing, strong cast, and great writing.  4.5 out of 5 stars"
}
];

module.exports = mustBuy;

/* Rules
*  do not user '&' use the word 'and'
*/