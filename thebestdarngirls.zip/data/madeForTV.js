var madeForTV = [
{
	"option":"a",
	"mtitle":"Fahrenheit 451",
	"review":"In this film adaptation, firemen in the future burn books because knowledge is dangerous.  A great start for the production company but the plotline has a slow burn. 3.5 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/fahrenheit451.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/fahrenheit451.jpg"
	}
},
{
	"option":"b",
	"mtitle":"Psycho Ex-Girlfriend",
	"review":"Newly engaged Kara and Tyler are loving life.  But when Kara discovers her new patient Isabelle is Tyler's crazy ex girlfriend no one will be safe.  It's a slow build but the last 10 minutes are exciting.  2 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/psychoexgirlfriend.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/psychoexgirlfriend.jpg"
	}
},
{
	"option":"c",
	"mtitle":"Harry and Meghan: A Royal Romance",
	"review":"Actress and activist Meghan Markle goes on a blind date with His Royal Highness Prince Harry.  With societal pressure, tough backgrounds, and papparazzi, can the couple make it? You know how this one will end but its fun to watch. 4.5 out of 5 stars",
		"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/harryandmeghanaroyalromance.jpeg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/harryandmeghanaroyalromance.jpeg"
	}
},
{
	"option":"d",
	"mtitle":"A Daughter's Revenge",
	"review":"Elle blames her step father for her mother's suicide.  She wants revenge and will sacrafice her friend to have it.  This movie will keep you glued to the TV.  Set yor DVR and watch it twice.  4 out of 5 stars",
	"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/adaughtersrevenge.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/adaughtersrevenge.jpg"
	}
},
{
	"option":"e",
	"mtitle":"Did I Kill My Mother",
	"review":"After a hard night of partying, Natalie publicly argues with her mother and goes to sleep.  The next morning her mother is dead, and she is the prime suspect.  This is a good mystery.  4 out of 5 stars",
		"image":{
		"smallImageUrl":"https://s3.amazonaws.com/thebestdarngirls/small-image/didikillmymother.jpg",
		"largeImageUrl":"https://s3.amazonaws.com/thebestdarngirls/large-image/didikillmymother.jpg"
	}
}
];

module.exports = madeForTV;

/* Rules
*  do not user '&' use the word 'and'
*/