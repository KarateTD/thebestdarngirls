var madeForTV = [
{
	"option":"a",
	"mtitle":"Fahrenheit 451",
	"review":"the review of Fahrenheit 451"
},
{
	"option":"b",
	"mtitle":"Psycho Ex-Girlfriend",
	"review":"the review of Psycho Ex-Girlfriend"
},
{
	"option":"c",
	"mtitle":"Harry and Meghan: A Royal Romance",
	"review":"the review of Harry and Meghan: A Royal Romance"
},
{
	"option":"d",
	"mtitle":"A Daughter's Revenge",
	"review":"the review of A Daughters' Revenge"
},
{
	"option":"e",
	"mtitle":"Did I Kill My Mother",
	"review":"the review of Did I Kill My Mother"
}
];

module.exports = madeForTV;

/* Rules
*  do not user '&' use the word 'and'
*/